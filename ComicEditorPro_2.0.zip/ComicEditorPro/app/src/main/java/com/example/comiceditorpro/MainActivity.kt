package com.example.comiceditorpro

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.*
import java.util.zip.ZipInputStream
import kotlin.math.abs
import kotlin.math.min

data class Page(val file: File, val name: String)
enum class Tool { NONE, BRUSH, LINE, RECT, OVAL, TEXT, CROP }

data class Mark(
 val kind: Tool,
 val points: List<Offset>,
 val color: Color,
 val width: Float,
 val text: String = ""
)

class MainViewModel : ViewModel() {
 var pages by mutableStateOf<List<Page>>(emptyList())
 var selected by mutableIntStateOf(0)
 var marksByPage = mutableStateMapOf<Int, List<Mark>>()
 var tool by mutableStateOf(Tool.BRUSH)
 var color by mutableStateOf(Color.Red)
 var width by mutableFloatStateOf(6f)
 var text by mutableStateOf("Text")
 var zoom by mutableFloatStateOf(1f)
 var readerMode by mutableStateOf(true)
 var brightness by mutableFloatStateOf(1f)
 var contrast by mutableFloatStateOf(1f)
 var saturation by mutableFloatStateOf(1f)
 private val history = ArrayDeque<List<Mark>>()
 private val redo = ArrayDeque<List<Mark>>()

 fun marks(): List<Mark> = marksByPage[selected].orEmpty()
 fun setMarks(v: List<Mark>) {
  history.addLast(marks()); if(history.size>30) history.removeFirst()
  marksByPage[selected]=v; redo.clear()
 }
 fun undo() {
  if(history.isNotEmpty()) { redo.addLast(marks()); marksByPage[selected]=history.removeLast() }
 }
 fun redo() {
  if(redo.isNotEmpty()) { history.addLast(marks()); marksByPage[selected]=redo.removeLast() }
 }
}

class MainActivity: ComponentActivity() {
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  setContent { ComicEditorPro() }
 }
}

@Composable
fun ComicEditorPro(vm: MainViewModel = viewModel()) {
 val ctx=androidx.compose.ui.platform.LocalContext.current
 var current by remember { mutableStateOf<Bitmap?>(null) }

 val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
  if(uri!=null) {
   val ext=(uri.lastPathSegment ?: "").substringAfterLast('.', "").lowercase()
   val mime=ctx.contentResolver.getType(uri).orEmpty()
   vm.pages = when {
    ext in listOf("zip","cbz","cbr") -> ArchiveReader.extract(ctx,uri,ext)
    ext=="pdf" || mime=="application/pdf" -> PdfReader.renderAll(ctx,uri)
    ext in listOf("mhtml","mht") || mime.contains("mhtml") -> MhtmlReader.extract(ctx,uri)
    else -> SingleReader.copy(ctx,uri)
   }
   vm.selected=0; vm.marksByPage.clear()
  }
 }

 LaunchedEffect(vm.selected,vm.pages,vm.brightness,vm.contrast,vm.saturation) {
  current=vm.pages.getOrNull(vm.selected)?.let { withContext(Dispatchers.IO) { BitmapFactory.decodeFile(it.file.path) } }
 }

 Column(Modifier.fillMaxSize()) {
  TopAppBar(title={Text("Comic Editor Pro")}, actions={
   TextButton({picker.launch(arrayOf("*/*"))}){Text("OPEN")}
   TextButton({vm.readerMode=!vm.readerMode}){Text(if(vm.readerMode)"EDIT" else "READER")}
  })
  if(vm.readerMode) {
   MangaReader(vm,current)
  } else {
   Editor(vm,current)
  }
 }
}

@Composable
fun MangaReader(vm: MainViewModel, bitmap: Bitmap?) {
 Row(Modifier.weight(1f).fillMaxWidth()) {
  LazyColumn(Modifier.width(70.dp).fillMaxHeight().background(MaterialTheme.colorScheme.surfaceVariant)) {
   itemsIndexed(vm.pages){i,_ -> TextButton({vm.selected=i}){Text("${i+1}")}}
  }
  Column(Modifier.weight(1f).fillMaxHeight()) {
   val scroll=rememberScrollState()
   Column(Modifier.fillMaxSize().horizontalScroll(scroll)) {
    vm.pages.forEachIndexed { i,p ->
     val b=if(i==vm.selected) bitmap else BitmapFactory.decodeFile(p.file.path)
     b?.let { androidx.compose.foundation.Image(it.asImageBitmap(),null,Modifier.fillMaxWidth()) }
    }
   }
  }
 }
}

@Composable
fun Editor(vm: MainViewModel, bitmap: Bitmap?) {
 Column(Modifier.weight(1f)) {
  Row(Modifier.fillMaxWidth().padding(4.dp), horizontalArrangement=Arrangement.spacedBy(4.dp)) {
   Button({vm.undo()}){Text("↶")}
   Button({vm.redo()}){Text("↷")}
   Button({vm.tool=Tool.BRUSH}){Text("Brush")}
   Button({vm.tool=Tool.LINE}){Text("Line")}
   Button({vm.tool=Tool.RECT}){Text("Rect")}
   Button({vm.tool=Tool.OVAL}){Text("Oval")}
   Button({vm.tool=Tool.TEXT}){Text("Text")}
   Button({vm.tool=Tool.CROP}){Text("Crop")}
  }
  Row(Modifier.fillMaxWidth().padding(4.dp), horizontalArrangement=Arrangement.spacedBy(4.dp)) {
   Button({vm.color=Color.Red}){Text("Red")}
   Button({vm.color=Color.Black}){Text("Black")}
   Button({vm.color=Color.Blue}){Text("Blue")}
   Button({vm.color=Color.White}){Text("White")}
  }
  Slider(vm.brightness,{vm.brightness=it},valueRange=0.4f..1.8f,Modifier.padding(horizontal=10.dp))
  Slider(vm.contrast,{vm.contrast=it},valueRange=0.4f..1.8f,Modifier.padding(horizontal=10.dp))
  Slider(vm.saturation,{vm.saturation=it},valueRange=0f..2f,Modifier.padding(horizontal=10.dp))
  EditorCanvas(vm,bitmap,Modifier.weight(1f).fillMaxWidth())
 }
}

@Composable
fun EditorCanvas(vm: MainViewModel, bitmap: Bitmap?, modifier: Modifier) {
 var start by remember { mutableStateOf<Offset?>(null) }
 var pts by remember { mutableStateOf(emptyList<Offset>()) }

 Canvas(modifier.pointerInput(vm.tool) {
  detectDragGestures(
   onDragStart={start=it;pts=listOf(it)},
   onDrag={c,_ ->
    pts=pts+c.position
    if(vm.tool==Tool.BRUSH) vm.setMarks(vm.marks()+Mark(Tool.BRUSH,pts,vm.color,vm.width))
   },
   onDragEnd={
    val s=start
    if(s!=null && vm.tool!=Tool.BRUSH) {
     vm.setMarks(vm.marks()+Mark(vm.tool,listOf(s,pts.lastOrNull()?:s),vm.color,vm.width,vm.text))
    }
    start=null;pts=emptyList()
   }
  )
 }) {
  bitmap?.let { drawImage(it.asImageBitmap()) }
  vm.marks().forEach { m ->
   when(m.kind) {
    Tool.BRUSH -> m.points.zipWithNext().forEach{(a,b)->drawLine(m.color,a,b,m.width)}
    Tool.LINE -> drawLine(m.color,m.points[0],m.points[1],m.width)
    Tool.RECT -> {
     val a=m.points[0];val b=m.points[1]
     drawRect(m.color,topLeft=Offset(min(a.x,b.x),min(a.y,b.y)),
      size=androidx.compose.ui.geometry.Size(abs(b.x-a.x),abs(b.y-a.y)),style=Stroke(m.width))
    }
    Tool.OVAL -> {
     val a=m.points[0];val b=m.points[1]
     drawOval(m.color,topLeft=Offset(min(a.x,b.x),min(a.y,b.y)),
      size=androidx.compose.ui.geometry.Size(abs(b.x-a.x),abs(b.y-a.y)),style=Stroke(m.width))
    }
    else -> {}
   }
  }
 }
}

object SingleReader {
 fun copy(c:Context,u:Uri):List<Page>{
  val f=File(c.cacheDir,"image_${System.currentTimeMillis()}.img")
  c.contentResolver.openInputStream(u)!!.use{input->FileOutputStream(f).use{input.copyTo(it)}}
  return listOf(Page(f,f.name))
 }
}

object ArchiveReader {
 fun extract(c:Context,u:Uri,ext:String):List<Page>{
  val dir=File(c.cacheDir,"archive_${System.currentTimeMillis()}").apply{mkdirs()}
  val out=mutableListOf<Page>()
  if(ext=="cbr") {
   // CBR is commonly RAR. Android's built-in ZIP reader cannot decode RAR.
   // The UI accepts CBR; production builds should add a RAR library here.
   return out
  }
  c.contentResolver.openInputStream(u)?.use{input->ZipInputStream(input).use{z->
   var e=z.nextEntry
   while(e!=null){
    if(!e.isDirectory && e.name.lowercase().matches(Regex(".*\.(jpg|jpeg|png|webp|gif)$"))){
     val f=File(dir,File(e.name).name)
     FileOutputStream(f).use{z.copyTo(it)}
     out+=Page(f,f.name)
    }
    e=z.nextEntry
   }
  }}
  return out.sortedBy{it.name.lowercase()}
 }
}

object PdfReader {
 fun renderAll(c:Context,u:Uri):List<Page>{
  val out=mutableListOf<Page>()
  val pfd=c.contentResolver.openFileDescriptor(u,"r") ?: return out
  PdfRenderer(pfd).use{r->
   val dir=File(c.cacheDir,"pdf_${System.currentTimeMillis()}").apply{mkdirs()}
   for(i in 0 until r.pageCount){
    r.openPage(i).use{p->
     val w=p.width*2;val h=p.height*2
     val b=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888)
     b.eraseColor(Color.WHITE.toArgb());p.render(b,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
     val f=File(dir,"page_%04d.png".format(i+1))
     FileOutputStream(f).use{b.compress(Bitmap.CompressFormat.PNG,100,it)}
     out+=Page(f,f.name)
    }
   }
  }
  pfd.close();return out
 }
}

object MhtmlReader {
 fun extract(c:Context,u:Uri):List<Page>{
  // Minimal MIME image extractor: finds base64 image parts in MHTML.
  val text=c.contentResolver.openInputStream(u)?.bufferedReader(Charsets.ISO_8859_1)?.readText() ?: return emptyList()
  val dir=File(c.cacheDir,"mhtml_${System.currentTimeMillis()}").apply{mkdirs()}
  val out=mutableListOf<Page>()
  val blocks=text.split(Regex("(?=Content-Type:\s*image/)"))
  var n=0
  for(block in blocks){
   val enc=Regex("Content-Transfer-Encoding:\s*base64",RegexOption.IGNORE_CASE).containsMatchIn(block)
   if(!enc) continue
   val body=block.substringAfter("\r\n\r\n",block.substringAfter("\n\n",""))
     .replace(Regex("\s+"),"")
   try{
    val bytes=android.util.Base64.decode(body,android.util.Base64.DEFAULT)
    if(bytes.size<20) continue
    val f=File(dir,"image_%04d.bin".format(++n))
    f.writeBytes(bytes);out+=Page(f,f.name)
   }catch(_:Exception){}
  }
  return out
 }
}
