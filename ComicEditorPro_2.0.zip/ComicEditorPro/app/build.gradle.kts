plugins {
 id("com.android.application")
 id("org.jetbrains.kotlin.android")
 id("org.jetbrains.kotlin.plugin.compose")
}
android {
 namespace="com.example.comiceditorpro"
 compileSdk=35
 defaultConfig {
  applicationId="com.example.comiceditorpro"
  minSdk=26
  targetSdk=35
  versionCode=2
  versionName="2.0"
 }
}
dependencies {
 implementation("androidx.core:core-ktx:1.15.0")
 implementation("androidx.activity:activity-compose:1.10.1")
 implementation("androidx.compose.ui:ui")
 implementation("androidx.compose.ui:ui-tooling-preview")
 implementation("androidx.compose.material3:material3")
 implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
 implementation("androidx.documentfile:documentfile:1.0.1")
 implementation("androidx.compose.foundation:foundation")
 implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.1")
 implementation("org.apache.commons:commons-compress:1.27.1")
 debugImplementation("androidx.compose.ui:ui-tooling")
}
