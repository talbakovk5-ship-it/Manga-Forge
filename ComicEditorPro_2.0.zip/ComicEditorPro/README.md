# Comic Editor Pro 2.0

Android/Kotlin + Jetpack Compose starter for a manga/manhwa reader + image editor.

## Implemented
- Image import
- PDF page rendering with Android PdfRenderer
- ZIP/CBZ image extraction
- Basic MHTML base64 image extraction
- Manga page list and vertical reader
- Brush, line, rectangle, oval
- Undo/redo history
- Color selection
- Brightness / contrast / saturation controls (UI/state ready)
- Crop tool placeholder
- Text tool state/shape architecture
- CBR input detection

## Production work still needed
- True RAR/CBR extraction using a RAR-capable library
- Full MHTML MIME parser and HTML/resource resolution
- Non-destructive color filter rendering
- Real crop UI and bitmap cropping
- Text placement, font/size controls and rasterization
- Export to PNG/JPEG/WebP/PDF/CBZ
- Persistent library/bookmarks/settings
- Gesture zoom/pan and page caching for very long manga
- Background decoding to avoid memory pressure

The project is designed so these can be added without rewriting the reader/editor architecture.
